export const API = process.env.NEXT_PUBLIC_API || 'http://localhost:4000';
export function token() { if (typeof window === 'undefined') return ''; return localStorage.getItem('token') || ''; }
export async function api(path: string, options: RequestInit = {}) {
  const headers = new Headers(options.headers);
  headers.set('Content-Type', 'application/json');
  const t = token(); if (t) headers.set('Authorization', `Bearer ${t}`);
  const res = await fetch(`${API}${path}`, { ...options, headers, cache: 'no-store' });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}
