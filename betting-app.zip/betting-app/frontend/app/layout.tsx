import './globals.css';
import Link from 'next/link';
export const metadata = { title: 'BET ★ ZONE Demo', description: 'Demo betting interface with virtual credits only' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>
    <header className="sticky top-0 z-20 border-b border-yellow-500/30 bg-black/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link href="/" className="text-2xl font-black tracking-widest text-yellow-400">BET ★ ZONE</Link>
        <nav className="flex gap-5 text-sm text-neutral-300"><Link href="/">Home</Link><Link href="/profile">Profile</Link><Link href="/login">Login</Link></nav>
      </div>
    </header>
    {children}
  </body></html>;
}
