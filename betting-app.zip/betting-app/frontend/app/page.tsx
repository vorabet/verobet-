'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { API, api } from '@/lib/api';

type Odd = { id:string; market:string; selection:string; value:string };
type Event = { id:string; sport:string; homeTeam:string; awayTeam:string; startTime:string; status:string; odds:Odd[] };
type Pick = { eventId:string; title:string; market:string; selection:string; odds:number } | null;

export default function Home() {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [pick, setPick] = useState<Pick>(null);
  const [stake, setStake] = useState('10');
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetch(`${API}/api/events`).then(r => { if (!r.ok) throw new Error('Could not load events'); return r.json(); })
      .then(setEvents).catch(e => setError(e.message)).finally(() => setLoading(false));
  }, []);

  async function placeBet() {
    if (!pick) return;
    setMessage('');
    try {
      const b = await api('/api/bets', { method:'POST', body: JSON.stringify({ eventId:pick.eventId, market:pick.market, selection:pick.selection, stake:Number(stake) }) });
      setMessage(`Demo bet placed. Potential win: ${Number(b.potentialWin).toFixed(2)}`);
      setPick(null);
    } catch (e:any) { setMessage(e.message === 'Unauthorized' ? 'Login first.' : e.message); }
  }

  return <main className="mx-auto max-w-6xl p-5">
    <section className="mb-7 rounded-2xl border border-yellow-500/30 bg-neutral-950 p-6">
      <p className="text-xs font-bold uppercase tracking-[.35em] text-yellow-400">Virtual credits only</p>
      <h1 className="mt-2 text-4xl font-black md:text-5xl">Sports demo dashboard</h1>
      <p className="mt-3 max-w-2xl text-neutral-400">Register to receive 1,000 demo credits. No deposits, withdrawals, or real-money payments are included.</p>
    </section>

    {loading && <p className="text-neutral-400">Loading events…</p>}
    {error && <p className="text-red-400">{error}</p>}

    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <section className="grid gap-4 md:grid-cols-2">
        {events.map(ev => <article key={ev.id} className="rounded-2xl border border-neutral-800 bg-neutral-900 p-5">
          <div className="flex items-start justify-between gap-3"><div><p className="text-xs uppercase text-yellow-400">{ev.sport}</p><h2 className="mt-1 font-bold">{ev.homeTeam} <span className="text-neutral-500">vs</span> {ev.awayTeam}</h2></div><span className="rounded-full bg-neutral-800 px-2 py-1 text-xs">{ev.status}</span></div>
          <p className="mt-2 text-xs text-neutral-500">{new Date(ev.startTime).toLocaleString()}</p>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {ev.odds.filter(o => o.market === '1X2').map(o => <button key={o.id} onClick={() => setPick({ eventId:ev.id, title:`${ev.homeTeam} vs ${ev.awayTeam}`, market:o.market, selection:o.selection, odds:Number(o.value) })} className="rounded-xl bg-yellow-400 px-3 py-3 font-bold text-black hover:bg-yellow-300"><span className="block text-xs">{o.selection}</span>{Number(o.value).toFixed(2)}</button>)}
          </div>
        </article>)}
      </section>

      <aside className="h-fit rounded-2xl border border-yellow-500/30 bg-neutral-950 p-5 lg:sticky lg:top-24">
        <h3 className="text-xl font-black text-yellow-400">Bet Slip</h3>
        {!pick ? <p className="mt-4 text-sm text-neutral-500">Choose an odd to add it here.</p> : <div className="mt-4 space-y-4"><div><p className="font-bold">{pick.title}</p><p className="text-sm text-neutral-400">{pick.selection} @ {pick.odds.toFixed(2)}</p></div><label className="block text-sm text-neutral-400">Stake<input value={stake} onChange={e=>setStake(e.target.value)} type="number" min="1" step="1" className="mt-1 w-full rounded-xl border border-neutral-700 bg-neutral-900 p-3 text-white" /></label><p className="text-sm">Potential: <b className="text-yellow-400">{(Number(stake || 0)*pick.odds).toFixed(2)}</b></p><button onClick={placeBet} className="w-full rounded-xl bg-yellow-400 py-3 font-black text-black">Place Demo Bet</button></div>}
        {message && <p className="mt-4 text-sm text-neutral-300">{message}</p>}
        <Link href="/profile" className="mt-5 block text-sm text-yellow-400">View my demo bets →</Link>
      </aside>
    </div>
  </main>;
}
