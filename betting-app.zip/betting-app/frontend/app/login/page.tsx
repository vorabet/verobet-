'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { API } from '@/lib/api';
export default function LoginPage() {
  const router = useRouter();
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [mode,setMode]=useState<'login'|'register'>('register'); const [error,setError]=useState('');
  async function submit(e:React.FormEvent){ e.preventDefault(); setError(''); const res=await fetch(`${API}/api/auth/${mode}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})}); const data=await res.json(); if(!res.ok){setError(data.error||'Request failed');return;} localStorage.setItem('token',data.token); router.push('/profile'); }
  return <main className="mx-auto max-w-md p-6"><div className="mt-12 rounded-2xl border border-yellow-500/30 bg-neutral-950 p-6"><h1 className="text-3xl font-black text-yellow-400">{mode==='register'?'Create demo account':'Login'}</h1><p className="mt-2 text-sm text-neutral-400">Demo accounts use virtual credits only.</p><form onSubmit={submit} className="mt-6 space-y-4"><input className="w-full rounded-xl border border-neutral-700 bg-neutral-900 p-3" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/><input className="w-full rounded-xl border border-neutral-700 bg-neutral-900 p-3" placeholder="Password (8+ characters)" type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={8}/>{error&&<p className="text-sm text-red-400">{error}</p>}<button className="w-full rounded-xl bg-yellow-400 py-3 font-black text-black">{mode==='register'?'Register':'Login'}</button></form><button onClick={()=>setMode(mode==='register'?'login':'register')} className="mt-4 text-sm text-yellow-400">{mode==='register'?'Already have an account? Login':'Need an account? Register'}</button></div></main>;
}
