# BET ZONE Demo

Demo-only sports betting interface using virtual credits. No real-money deposits or withdrawals are included.

## 1. Start PostgreSQL
```bash
docker compose up -d
```

## 2. Backend
```bash
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```
Backend: http://localhost:4000

## 3. Frontend
Open another terminal:
```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```
Frontend: http://localhost:3000

Registering creates an account with 1,000 virtual demo credits.
