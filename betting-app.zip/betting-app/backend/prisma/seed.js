require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const now = new Date();
  const events = [
    { sport: 'Football', homeTeam: 'Madrid Stars', awayTeam: 'Barcelona City', hours: 3, odds: [1.85, 3.40, 3.95] },
    { sport: 'Football', homeTeam: 'London Reds', awayTeam: 'Manchester Blues', hours: 6, odds: [2.20, 3.25, 2.95] },
    { sport: 'Basketball', homeTeam: 'LA Gold', awayTeam: 'Boston Green', hours: 9, odds: [1.72, 4.10, 2.15] }
  ];

  for (const item of events) {
    const event = await prisma.event.create({
      data: {
        sport: item.sport,
        homeTeam: item.homeTeam,
        awayTeam: item.awayTeam,
        startTime: new Date(now.getTime() + item.hours * 60 * 60 * 1000),
        odds: {
          create: [
            { market: '1X2', selection: 'HOME', value: item.odds[0] },
            { market: '1X2', selection: 'DRAW', value: item.odds[1] },
            { market: '1X2', selection: 'AWAY', value: item.odds[2] }
          ]
        }
      }
    });
    console.log('Seeded', event.homeTeam, 'vs', event.awayTeam);
  }
}

main().finally(() => prisma.$disconnect());
