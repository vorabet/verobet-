require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

if (!process.env.JWT_SECRET) throw new Error('JWT_SECRET is required');

const prisma = new PrismaClient();
const app = express();
const PORT = Number(process.env.PORT || 4000);

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000' }));
app.use(express.json({ limit: '32kb' }));
app.use(rateLimit({ windowMs: 60_000, max: 120 }));

function sign(user) {
  return jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '12h' });
}

function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Unauthorized' });
  }
}

app.get('/health', (_req, res) => res.json({ ok: true, mode: 'demo' }));

app.post('/api/auth/register', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!email || password.length < 8 || password.length > 128) {
    return res.status(400).json({ error: 'Invalid input' });
  }
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: { email, passwordHash, balance: 1000 },
      select: { id: true, email: true, role: true, balance: true }
    });
    res.status(201).json({ token: sign(user), user });
  } catch (e) {
    if (e.code === 'P2002') return res.status(409).json({ error: 'Email already exists' });
    console.error(e);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: 'Wrong credentials' });
  }
  res.json({ token: sign(user) });
});

app.get('/api/events', async (_req, res) => {
  const events = await prisma.event.findMany({
    where: { status: { in: ['UPCOMING', 'LIVE'] } },
    include: { odds: true },
    orderBy: { startTime: 'asc' }
  });
  res.json(events);
});

app.post('/api/bets', auth, async (req, res) => {
  const { eventId, market, selection } = req.body;
  const stake = Number(req.body.stake);
  if (!eventId || !market || !selection || !Number.isFinite(stake) || stake <= 0 || stake > 100000) {
    return res.status(400).json({ error: 'INVALID_BET' });
  }

  try {
    const bet = await prisma.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT id FROM "User" WHERE id = ${req.user.id} FOR UPDATE`;
      const user = await tx.user.findUnique({ where: { id: req.user.id } });
      if (!user) throw new Error('USER_NOT_FOUND');

      const event = await tx.event.findUnique({ where: { id: eventId } });
      if (!event) throw new Error('EVENT_NOT_FOUND');
      if (!['UPCOMING', 'LIVE'].includes(event.status)) throw new Error('EVENT_CLOSED');

      const odd = await tx.odd.findUnique({
        where: { eventId_market_selection: { eventId, market, selection } }
      });
      if (!odd) throw new Error('INVALID_SELECTION');

      const currentBalance = Number(user.balance);
      if (currentBalance < stake) throw new Error('INSUFFICIENT_BALANCE');
      const newBalance = currentBalance - stake;
      const potentialWin = stake * Number(odd.value);

      await tx.user.update({ where: { id: req.user.id }, data: { balance: newBalance } });
      const created = await tx.bet.create({
        data: {
          userId: req.user.id,
          eventId,
          market,
          selection,
          stake,
          odds: odd.value,
          potentialWin
        }
      });
      await tx.transaction.create({
        data: {
          userId: req.user.id,
          type: 'BET',
          amount: -stake,
          balanceAfter: newBalance,
          ref: created.id
        }
      });
      return created;
    });
    res.status(201).json(bet);
  } catch (e) {
    const known = ['USER_NOT_FOUND','EVENT_NOT_FOUND','EVENT_CLOSED','INVALID_SELECTION','INSUFFICIENT_BALANCE'];
    if (known.includes(e.message)) return res.status(400).json({ error: e.message });
    console.error(e);
    res.status(500).json({ error: 'INTERNAL_SERVER_ERROR' });
  }
});

app.get('/api/me', auth, async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    select: { id: true, email: true, balance: true, role: true, createdAt: true }
  });
  res.json(user);
});

app.get('/api/me/bets', auth, async (req, res) => {
  const bets = await prisma.bet.findMany({
    where: { userId: req.user.id },
    include: { event: true },
    orderBy: { createdAt: 'desc' }
  });
  res.json(bets);
});

app.listen(PORT, () => console.log(`Demo API on :${PORT}`));

async function shutdown() {
  await prisma.$disconnect();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
